import xbmcaddon

MainBase = 'https://pastebin.com/raw/YmpEeeHv'
addon = xbmcaddon.Addon('plugin.video.SportsHUB')