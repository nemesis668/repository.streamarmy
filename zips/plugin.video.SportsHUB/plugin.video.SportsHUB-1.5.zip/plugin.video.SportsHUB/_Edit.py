import xbmcaddon

MainBase = 'https://nsportshub.000webhostapp.com/new/home.txt'
addon = xbmcaddon.Addon('plugin.video.SportsHUB')