import xbmcaddon

MainBase = 'https://pastebin.com/raw/AahrVnVw'
addon = xbmcaddon.Addon('plugin.video.SportsHUB')