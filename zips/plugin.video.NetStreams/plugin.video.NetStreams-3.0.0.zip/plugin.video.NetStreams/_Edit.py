import xbmcaddon

MainBase = 'https://pastebin.com/raw/pcY7Gwf7'
addon = xbmcaddon.Addon('plugin.video.NetStreams')