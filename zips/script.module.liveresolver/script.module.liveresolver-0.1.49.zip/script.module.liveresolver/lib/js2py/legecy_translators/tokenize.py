from jsparser import *
from utils import *
# maybe I will try rewriting my parser in the future... Tokenizer makes things much easier and faster, unfortunately I
# did not know anything about parsers when I was starting this project so I invented my own.
